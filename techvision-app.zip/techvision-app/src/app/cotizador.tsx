export { default } from '../../screens/CotizadorScreen';
