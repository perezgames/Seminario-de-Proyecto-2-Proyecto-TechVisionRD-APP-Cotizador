export { default } from '../../screens/InicioScreen';
