export { default } from '../../screens/NosotrosScreen';
