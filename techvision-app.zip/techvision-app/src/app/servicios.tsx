export { default } from '../../screens/ServiciosScreen';
