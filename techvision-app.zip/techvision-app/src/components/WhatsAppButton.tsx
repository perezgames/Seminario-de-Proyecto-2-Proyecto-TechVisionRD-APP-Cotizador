import { Ionicons } from '@expo/vector-icons';
import { Linking, StyleSheet, TouchableOpacity } from 'react-native';

export default function WhatsAppButton() {
  return (
    <TouchableOpacity
      style={styles.button}
      onPress={() => Linking.openURL('https://wa.me/18494093006')}
    >
      <Ionicons name="logo-whatsapp" size={28} color="#fff" />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    position: 'absolute',
    bottom: 80,
    right: 20,
    backgroundColor: '#25D366',
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    zIndex: 999,
  },
});